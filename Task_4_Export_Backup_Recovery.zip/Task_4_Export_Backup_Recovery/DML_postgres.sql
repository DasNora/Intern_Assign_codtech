Problem 4:

Find the total number of crimes recorded in the CRIME table.

SOLUTION:

	SELECT COUNT(*) 
	FROM "chicago_crime_data";

Problem 5:

List community area names and numbers with per capita income less than 11000.

SOLUTION:

	SELECT DISTINCT "Community Area Number" AS "COMMUNITY AREA NUMBER", "COMMUNITY AREA NAME" AS "COMMUNITY AREA NAME"
	FROM "census_data"
	WHERE "PER CAPITA INCOME" < 11000
	ORDER BY "Community Area Number";

Problem 6:

List all case numbers for crimes involving minors?(children are not considered minors for the purposes of crime analysis)¶

SOLUTION:

	SELECT "Case_Number", "Description" 
	FROM "chicago_crime_data"
	WHERE "Description" LIKE '%MINOR%';

Problem 7:

List all kidnapping crimes involving a child?¶

SOLUTION:

	SELECT "Date", "Case_Number", "Primary_Type" AS "TYPE OF CRIME", "Description" AS "DESCRIPTION"
	FROM "chicago_crime_data"
	WHERE "Primary_Type" LIKE '%KIDNAPPING%' AND "Description" LIKE '%CHILD%'
	ORDER BY "Case_Number";

Problem 8:

List the kind of crimes that were recorded at schools. (No repetitions)

SOLUTION:

	SELECT DISTINCT "Primary_Type" AS "TYPE OF CRIME IN SCHOOL"
	FROM "chicago_crime_data"
	WHERE "Location_Description" ILIKE '%school%';

Problem 9:

List the type of schools along with the average safety score for each type.

SOLUTION:

	SELECT "Elementary_Middle_or_High_School" AS "TYPE OF SCHOOL", AVG("Safety_Score") AS "AVERAGE SAFETY SCORE"
	FROM "chicago_school_data"
	GROUP BY "Elementary_Middle_or_High_School";

Problem 10:

List 5 community areas with highest % of households below poverty line

SOLUTION:

	SELECT "COMMUNITY AREA NAME" AS "TOP 5 COMMUNITY AREA WITH HIGHEST % OF HOUSEHOLDS BELOW POVERTY LINE",MAX("PERCENT HOUSEHOLDS BELOW POVERTY") AS "HIGHEST PERCENTAGE"
	FROM "census_data"
	GROUP BY "COMMUNITY AREA NAME"
	ORDER BY MAX("PERCENT HOUSEHOLDS BELOW POVERTY") DESC
	LIMIT 5;

Problem 11:

Which community area is most crime prone? Display the coumminty area number only.

SOLUTION:

	SELECT "Community Area", COUNT("Community Area") AS "NO_OF_CRIMES"
	FROM "chicago_crime_data"
	GROUP BY "Community Area"
	ORDER BY "NO_OF_CRIMES" DESC
	LIMIT 1;

Problem 12:

Use a sub-query to find the name of the community area with highest hardship index

SOLUTION:

	SELECT distinct "COMMUNITY AREA NAME", "HARDSHIP INDEX"
	FROM "census_data"
	WHERE "HARDSHIP INDEX" = (SELECT MAX("HARDSHIP INDEX") FROM "census_data");

Problem 13:

Use a sub-query to determine the Community Area Name with most number of crimes?

SOLUTION:

	SELECT "Community Area", "NO_OF_CRIMES"
	FROM (
    SELECT "Community Area", COUNT("Community Area") AS "NO_OF_CRIMES"
    FROM "chicago_crime_data"
    GROUP BY "Community Area"
	) AS sub
	ORDER BY "NO_OF_CRIMES" DESC
	LIMIT 1;

Problem 14:

Find the total number of arrests from 2008 to 2012 in each community area along with the community areas name.

SOLUTION:

	SELECT c."COMMUNITY AREA NAME", COUNT(c."COMMUNITY AREA NAME") AS "NO_OF_ARRESTS"
	FROM "census_data" c
	LEFT JOIN "chicago_crime_data" d 
	ON d."Community Area" ~ '^\d+$' -- only rows where "Community Area" is digits
	AND c."Community Area Number" = d."Community Area"::integer
	WHERE d."Arrest" = 0
	GROUP BY c."COMMUNITY AREA NAME"
	ORDER BY c."COMMUNITY AREA NAME";

Problem 15:

Get the average per capita income for the top 5 community areas with the highest number of school enrollments.

SOLUTION:

	SELECT AVG(c."PER CAPITA INCOME") AS "Average Income of Top 5 School-Dense Areas"
	FROM (
    SELECT "Community_Area_Number"
    FROM "chicago_school_data"
    GROUP BY "Community_Area_Number"
    ORDER BY COUNT(*) DESC
    LIMIT 5
	) AS top5
	INNER JOIN "census_data" c
	ON top5."Community_Area_Number" = c."Community Area Number";

Problem 16: 

List all schools and their corresponding arrest counts in their community area. Include schools even if there were no arrests.

SOLUTION:

	WITH cleaned_crime AS (
	SELECT *
	FROM "chicago_crime_data"
	WHERE "Community Area" ~ '^\d+$'
	)
	SELECT s."Name_of_School" AS "SCHOOL NAME", 
       COUNT(s."Name_of_School") AS "NO_OF_ARRESTS"
	FROM "chicago_school_data" s
	RIGHT JOIN cleaned_crime c
	ON s."Community_Area_Number" = c."Community Area"::INTEGER
	WHERE c."Arrest" = 0
	GROUP BY s."Name_of_School"
	ORDER BY s."Name_of_School";

Problem 17:

Find the community areas with per capita income less than $20,000 and more than 100 arrests between 2008 and 2012.

SOLUTION:

	WITH filtered_crime AS (
    SELECT "Community Area"::INTEGER AS community_area
    FROM "chicago_crime_data"
    WHERE "Arrest" = 0 AND "Year" BETWEEN 2008 AND 2012AND "Community Area" ~ '^\d+$'
	),
	arrest_counts AS (
    SELECT community_area, COUNT(*) AS arrest_count
    FROM filtered_crime
    GROUP BY community_area
    HAVING COUNT(*) > 100
	)
	SELECT c."Community Area Number", c."COMMUNITY AREA NAME"
	FROM "census_data" c
	JOIN arrest_counts a
	ON c."Community Area Number" = a.community_area
	WHERE c."PER CAPITA INCOME" < 20000;